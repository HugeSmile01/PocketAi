# Model Licenses

| Model | License | Commercial OK | Hardware Resale OK |
|-------|---------|--------------|-------------------|
| Qwen2.5-1.5B | Qwen License (Apache-2.0 compatible) | Yes | Yes, with attribution |
| Qwen2.5-3B | Qwen License | Yes | Yes |
| Qwen2.5-7B | Qwen License | Yes | Yes |
| SmolLM2-1.7B | Apache 2.0 | Yes | Yes |
| Phi-3.5-mini | MIT | Yes | Yes |

## Attribution requirement (Qwen)

When shipping Qwen models in a commercial product, include:

> This product includes Qwen2.5 models by Alibaba Cloud, licensed under the Qwen License.
> https://huggingface.co/Qwen

## What you cannot do

- Claim the model as your own original work
- Remove attribution notices
- Use the Alibaba Cloud or Qwen trademark to endorse your product
