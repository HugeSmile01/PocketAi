# PocketAI Plugin Specification

Plugins extend PocketAI with specialized tools. They live in `app/plugins/` and are loaded dynamically.

## Plugin Structure

```
app/plugins/
  my-plugin/
    manifest.json     ← required
    plugin.js         ← required
    icon.svg          ← optional
    README.md         ← optional
```

## manifest.json

```json
{
  "id": "my-plugin",
  "name": "My Plugin",
  "version": "1.0.0",
  "description": "What this plugin does",
  "entrypoint": "plugin.js",
  "icon": "◈",
  "author": "Your Name",
  "permissions": ["llm-inference"]
}
```

### Permissions

| Permission | What it allows |
|---|---|
| `llm-inference` | Call the local LLM |
| `file-read` | Read files from the flash drive |
| `indexeddb` | Store data in IndexedDB |

## plugin.js

Your plugin exports a `render(panel)` function:

```javascript
export function render(panel) {
  panel.innerHTML = `
    <h3>My Plugin</h3>
    <button id="run">Run</button>
    <div id="output"></div>
  `;

  panel.querySelector('#run').onclick = async () => {
    const response = await callLLM(
      'You are a helpful assistant.',
      'Hello!',
      (token, full) => {
        panel.querySelector('#output').textContent = full;
      }
    );
  };
}

async function callLLM(system, user, onToken) {
  const r = await fetch('http://127.0.0.1:8080/v1/chat/completions', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      model: 'local',
      messages: [
        { role: 'system', content: system },
        { role: 'user', content: user }
      ],
      stream: true,
      max_tokens: 512
    })
  });
  // ... handle SSE stream
}
```

## Loading External Plugins

Place your plugin folder in `app/plugins/` on the flash drive and it will appear in the plugin grid automatically on next launch.
